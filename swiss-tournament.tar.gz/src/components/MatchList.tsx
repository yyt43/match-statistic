import { Swords, Clock, Check, X, UserMinus, Trophy, Award, Medal } from 'lucide-react';
import { useTournamentStore } from '../store/useTournamentStore';
import { RoundTabs } from './RoundTabs';
import type { Match, MatchResult } from '../types';
import { useMemo, useState } from 'react';

export function MatchList() {
  const { tournament, viewRound, updateMatchResult } = useTournamentStore();
  const [editingMatch, setEditingMatch] = useState<string | null>(null);
  
  const matches = useMemo(() => {
    return tournament.matches.filter(m => m.round === viewRound);
  }, [tournament.matches, viewRound]);
  
  const playerMap = useMemo(() => {
    const map = new Map();
    tournament.players.forEach(p => map.set(p.id, p));
    return map;
  }, [tournament.players]);

  const getPlayerName = (id: string) => {
    if (id === 'bye') return '轮空';
    return playerMap.get(id)?.name || '未知选手';
  };

  const getPlayerRank = (id: string) => {
    if (id === 'bye') return null;
    return playerMap.get(id)?.previousRank;
  };

  const handleResultClick = (matchId: string) => {
    if (tournament.status === 'completed') return;
    const match = tournament.matches.find(m => m.id === matchId);
    if (match?.isBye) return;
    if (viewRound !== tournament.currentRound) return;
    setEditingMatch(editingMatch === matchId ? null : matchId);
  };

  const handleSetResult = (matchId: string, result: MatchResult) => {
    updateMatchResult(matchId, result);
    setEditingMatch(null);
  };

  const getResultBadge = (match: Match) => {
    if (match.isBye) {
      return (
        <span className="flex items-center gap-1 text-xs text-amber-400 bg-amber-500/10 px-2 py-1 rounded-full">
          <UserMinus className="w-3 h-3" />
          轮空
        </span>
      );
    }
    
    if (match.result === 'pending') {
      return (
        <span className="flex items-center gap-1 text-xs text-slate-400 bg-slate-500/20 px-2 py-1 rounded-full">
          <Clock className="w-3 h-3" />
          待进行
        </span>
      );
    }
    
    return (
      <span className="flex items-center gap-1 text-xs text-emerald-400 bg-emerald-500/20 px-2 py-1 rounded-full">
        <Check className="w-3 h-3" />
        已完成
      </span>
    );
  };

  const isWinner = (match: Match, playerNum: 1 | 2) => {
    if (match.result === 'player1') return playerNum === 1;
    if (match.result === 'player2') return playerNum === 2;
    return false;
  };

  const isLoser = (match: Match, playerNum: 1 | 2) => {
    if (match.result === 'player1') return playerNum === 2;
    if (match.result === 'player2') return playerNum === 1;
    return false;
  };

  const getRankIcon = (rank: number | undefined) => {
    if (!rank) return null;
    if (rank === 1) return <Trophy className="w-3 h-3 text-gold-400" />;
    if (rank === 2) return <Medal className="w-3 h-3 text-slate-300" />;
    if (rank === 3) return <Award className="w-3 h-3 text-amber-600" />;
    return null;
  };

  if (tournament.currentRound === 0) {
    return (
      <div className="glass-panel rounded-2xl p-5 h-full flex flex-col">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-display text-lg font-bold text-white flex items-center gap-2">
            <Swords className="w-5 h-5 text-gold-400" />
            对阵表
          </h2>
        </div>
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center text-slate-500">
            <Swords className="w-16 h-16 mx-auto mb-4 opacity-20" />
            <p className="text-sm">比赛尚未开始</p>
            <p className="text-xs mt-1">点击右侧"开始比赛"生成对阵</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="glass-panel rounded-2xl p-5 h-full flex flex-col">
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-display text-lg font-bold text-white flex items-center gap-2">
          <Swords className="w-5 h-5 text-gold-400" />
          第 {viewRound} 轮对阵表
        </h2>
        <RoundTabs />
      </div>
      
      <div className="flex-1 overflow-y-auto space-y-2 pr-1">
        {matches.length === 0 ? (
          <div className="text-center py-12 text-slate-500">
            <Swords className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <p className="text-sm">暂无对阵信息</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2">
            {matches.map((match, index) => (
              <div
                key={match.id}
                className={`
                  relative bg-slate-800/40 rounded-xl p-3 transition-all duration-300
                  border border-transparent hover:border-gold-500/20
                  ${editingMatch === match.id ? 'ring-2 ring-gold-500/50' : ''}
                `}
                onClick={() => handleResultClick(match.id)}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] text-slate-500 font-mono">
                    场次 {index + 1}
                  </span>
                  {getResultBadge(match)}
                </div>
                
                <div className="space-y-2">
                  <div className={`
                    py-1.5 px-2 rounded-lg text-center text-sm transition-all font-bold
                    ${isWinner(match, 1) ? 'bg-yellow-500 text-white' : ''}
                    ${isLoser(match, 1) ? 'bg-black text-white' : ''}
                    ${match.result === 'pending' && !match.isBye ? 'cursor-pointer hover:bg-slate-700/50 text-white' : ''}
                    ${match.isBye && match.player1Id !== 'bye' ? 'bg-amber-500 text-white' : ''}
                  `}>
                    <div className="flex items-center justify-center gap-1">
                      {getRankIcon(getPlayerRank(match.player1Id))}
                      <span className="truncate max-w-[120px]">{getPlayerName(match.player1Id)}</span>
                    </div>
                    {match.player1Id !== 'bye' && (
                      <div className="text-[10px] mt-0.5">
                        {playerMap.get(match.player1Id)?.wins}-{playerMap.get(match.player1Id)?.losses}
                      </div>
                    )}
                  </div>
                  
                  <div className="flex items-center justify-center py-1">
                    <div className="w-8 h-8 rounded-full bg-indigo-900/50 flex items-center justify-center border border-gold-500/30">
                      <span className="font-display text-[10px] font-bold text-gold-400">
                        VS
                      </span>
                    </div>
                  </div>
                  
                  <div className={`
                    py-1.5 px-2 rounded-lg text-center text-sm transition-all font-bold
                    ${isWinner(match, 2) ? 'bg-yellow-500 text-white' : ''}
                    ${isLoser(match, 2) ? 'bg-black text-white' : ''}
                    ${match.result === 'pending' && !match.isBye ? 'cursor-pointer hover:bg-slate-700/50 text-white' : ''}
                    ${match.player2Id === 'bye' ? 'bg-amber-500 text-white' : ''}
                  `}>
                    <div className="flex items-center justify-center gap-1">
                      {getRankIcon(getPlayerRank(match.player2Id))}
                      <span className="truncate max-w-[120px]">{getPlayerName(match.player2Id)}</span>
                    </div>
                    {match.player2Id !== 'bye' && (
                      <div className="text-[10px] mt-0.5">
                        {playerMap.get(match.player2Id)?.wins}-{playerMap.get(match.player2Id)?.losses}
                      </div>
                    )}
                  </div>
                </div>
                
                {editingMatch === match.id && !match.isBye && (
                  <div 
                    className="mt-3 pt-3 border-t border-slate-700/50 flex items-center justify-center gap-2"
                    onClick={e => e.stopPropagation()}
                  >
                    <button
                      onClick={() => handleSetResult(match.id, 'player1')}
                      className="flex-1 py-1.5 rounded-lg text-xs font-medium bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30 transition-colors"
                    >
                      上方胜
                    </button>
                    <button
                      onClick={() => handleSetResult(match.id, 'player2')}
                      className="flex-1 py-1.5 rounded-lg text-xs font-medium bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30 transition-colors"
                    >
                      下方胜
                    </button>
                    <button
                      onClick={() => handleSetResult(match.id, 'pending')}
                      className="px-2 py-1.5 rounded-lg text-xs text-rose-400 hover:bg-rose-500/10 transition-colors"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
