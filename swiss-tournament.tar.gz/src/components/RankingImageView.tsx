import { useTournamentStore } from '../store/useTournamentStore';
import { useMemo } from 'react';

export function RankingImageView() {
  const { tournament } = useTournamentStore();

  const rankedPlayers = useMemo(() => {
    const players = [...tournament.players];
    return players.sort((a, b) => {
      if (b.winRate !== a.winRate) return b.winRate - a.winRate;
      if (b.opponentWinRate !== a.opponentWinRate) return b.opponentWinRate - a.opponentWinRate;
      if (b.opponentOpponentWinRate !== a.opponentOpponentWinRate) return b.opponentOpponentWinRate - a.opponentOpponentWinRate;
      if (b.points !== a.points) return b.points - a.points;
      return a.name.localeCompare(b.name);
    });
  }, [tournament.players, tournament.matches]);

  const getPlayerMatchHistory = (playerId: string) => {
    const history: { round: number; result: 'win' | 'loss' | 'bye' }[] = [];
    for (let round = 1; round <= tournament.totalRounds; round++) {
      const match = tournament.matches.find(
        m => m.round === round && (m.player1Id === playerId || m.player2Id === playerId)
      );
      if (!match) continue;
      if (match.isBye) {
        history.push({ round, result: 'bye' });
      } else if (match.result === 'player1') {
        history.push({ round, result: match.player1Id === playerId ? 'win' : 'loss' });
      } else if (match.result === 'player2') {
        history.push({ round, result: match.player2Id === playerId ? 'win' : 'loss' });
      }
    }
    return history;
  };

  const getResultBlock = (result: 'win' | 'loss' | 'bye') => {
    if (result === 'win') {
      return <span className="inline-flex items-center justify-center w-5 h-5 rounded text-[10px] font-bold text-white bg-red-500">胜</span>;
    }
    if (result === 'loss') {
      return <span className="inline-flex items-center justify-center w-5 h-5 rounded text-[10px] font-bold text-white bg-black border border-slate-600">负</span>;
    }
    return <span className="inline-flex items-center justify-center w-5 h-5 rounded text-[10px] font-bold text-white bg-amber-500">轮</span>;
  };

  if (tournament.currentRound === 0) {
    return (
      <div id="ranking-image" className="p-6 bg-slate-900 min-h-[400px]">
        <div className="text-center text-slate-500 py-20">暂无排行榜数据</div>
      </div>
    );
  }

  return (
    <div id="ranking-image" className="p-6 bg-slate-900" style={{ width: 1000 }}>
      <div className="bg-slate-800 rounded-lg overflow-hidden">
        <div className="px-5 py-3 bg-slate-700/50 border-b border-slate-700">
          <h2 className="text-base font-bold text-white">{tournament.name} - 排行榜</h2>
          <p className="text-xs text-slate-400 mt-1">共 {tournament.totalRounds} 轮 · {rankedPlayers.length} 人参赛</p>
        </div>

        <div className="grid grid-cols-12 gap-2 px-5 py-2.5 text-xs text-slate-400 bg-slate-800/80">
          <div className="col-span-1">排名</div>
          <div className="col-span-3">选手名称</div>
          <div className="col-span-1 text-center">战绩</div>
          <div className="col-span-2 text-center">对手胜率</div>
          <div className="col-span-2 text-center">对手对手胜率</div>
          <div className="col-span-3 text-center">比赛历史</div>
        </div>

        <div>
          {rankedPlayers.map((player, index) => {
            const rank = index + 1;
            const history = getPlayerMatchHistory(player.id);
            const bgColor = index % 2 === 0 ? 'bg-slate-800/40' : 'bg-slate-800/70';

            return (
              <div
                key={player.id}
                className={`grid grid-cols-12 gap-2 px-5 py-3 items-center text-sm ${bgColor}`}
              >
                <div className="col-span-1 font-bold text-slate-300">{rank}</div>
                <div className="col-span-3 font-medium text-white truncate">{player.name}</div>
                <div className="col-span-1 text-center font-mono font-bold text-white">{player.wins}-{player.losses}</div>
                <div className="col-span-2 text-center text-slate-300">{Math.round(player.opponentWinRate * 100)}%</div>
                <div className="col-span-2 text-center text-slate-300">{Math.round(player.opponentOpponentWinRate * 100)}%</div>
                <div className="col-span-3 flex gap-1 justify-center">
                  {history.length > 0 ? history.map((h, i) => <span key={i}>{getResultBlock(h.result)}</span>) : <span className="text-xs text-slate-500">无结果</span>}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="mt-4 flex items-center justify-center gap-6 text-xs text-slate-400">
        <div className="flex items-center gap-1.5">
          <span className="inline-block w-3 h-3 rounded bg-red-500"></span>
          <span>胜</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="inline-block w-3 h-3 rounded bg-black border border-slate-600"></span>
          <span>负</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="inline-block w-3 h-3 rounded bg-amber-500"></span>
          <span>轮空</span>
        </div>
      </div>
    </div>
  );
}
