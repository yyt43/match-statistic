import { Trophy, Medal, Award, BarChart2, Users } from 'lucide-react';
import { useTournamentStore } from '../store/useTournamentStore';
import type { Player, Match } from '../types';
import { useMemo } from 'react';

export function PlayerRanking() {
  const { tournament } = useTournamentStore();
  
  const rankedPlayers = useMemo(() => {
    const players = [...tournament.players];
    return players.sort((a, b) => {
      if (b.winRate !== a.winRate) return b.winRate - a.winRate;
      if (b.opponentWinRate !== a.opponentWinRate) return b.opponentWinRate - a.opponentWinRate;
      if (b.opponentOpponentWinRate !== a.opponentOpponentWinRate) return b.opponentOpponentWinRate - a.opponentOpponentWinRate;
      if (b.points !== a.points) return b.points - a.points;
      return a.name.localeCompare(b.name);
    });
  }, [tournament.players, tournament.matches]);

  const getPlayerMatchHistory = (playerId: string): { round: number; result: 'win' | 'loss' | 'bye' }[] => {
    const history: { round: number; result: 'win' | 'loss' | 'bye' }[] = [];
    
    for (let round = 1; round <= tournament.totalRounds; round++) {
      const match = tournament.matches.find(
        m => m.round === round && (m.player1Id === playerId || m.player2Id === playerId)
      );
      
      if (!match) {
        continue;
      }
      
      if (match.isBye) {
        history.push({ round, result: 'bye' });
      } else if (match.result === 'player1') {
        history.push({ round, result: match.player1Id === playerId ? 'win' : 'loss' });
      } else if (match.result === 'player2') {
        history.push({ round, result: match.player2Id === playerId ? 'win' : 'loss' });
      }
    }
    
    return history;
  };

  const getRankBadge = (rank: number) => {
    if (rank === 1) {
      return <Trophy className="w-5 h-5 text-yellow-400" />;
    }
    if (rank === 2) {
      return <Medal className="w-5 h-5 text-slate-300" />;
    }
    if (rank === 3) {
      return <Award className="w-5 h-5 text-amber-500" />;
    }
    return <span className="text-lg font-bold text-slate-400">{rank}</span>;
  };

  const getResultBlock = (result: 'win' | 'loss' | 'bye') => {
    if (result === 'win') {
      return (
        <div className="w-5 h-5 rounded bg-red-500 flex items-center justify-center text-[10px] font-bold text-white">
          胜
        </div>
      );
    }
    if (result === 'loss') {
      return (
        <div className="w-5 h-5 rounded bg-black border border-slate-600 flex items-center justify-center text-[10px] font-bold text-white">
          负
        </div>
      );
    }
    return (
      <div className="w-5 h-5 rounded bg-amber-500 flex items-center justify-center text-[10px] font-bold text-white">
        轮
      </div>
    );
  };

  if (tournament.currentRound === 0) {
    return (
      <div className="glass-panel rounded-2xl p-5 h-full flex flex-col">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-display text-lg font-bold text-white flex items-center gap-2">
            <BarChart2 className="w-5 h-5 text-gold-400" />
            排行榜
          </h2>
        </div>
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center text-slate-500">
            <BarChart2 className="w-16 h-16 mx-auto mb-4 opacity-20" />
            <p className="text-sm">比赛尚未开始</p>
            <p className="text-xs mt-1">开始比赛后将显示排名</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="glass-panel rounded-2xl p-5 h-full flex flex-col">
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-display text-lg font-bold text-white flex items-center gap-2">
          <BarChart2 className="w-5 h-5 text-gold-400" />
          排行榜
        </h2>
        <div className="flex items-center gap-3 text-xs text-slate-400">
          <div className="flex items-center gap-1">
            <Users className="w-3 h-3" />
            <span>{rankedPlayers.filter(p => !p.dropped).length} 人参赛</span>
          </div>
          {rankedPlayers.some(p => p.dropped) && (
            <span className="text-rose-400">{rankedPlayers.filter(p => p.dropped).length} 人弃赛</span>
          )}
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto pr-1">
        <div className="bg-slate-800/60 rounded-lg mb-2">
          <div className="grid grid-cols-12 gap-2 px-4 py-2 text-xs font-medium text-slate-400">
            <div className="col-span-1">排名</div>
            <div className="col-span-3">选手名称</div>
            <div className="col-span-1 text-center">战绩</div>
            <div className="col-span-2 text-center">对手胜率</div>
            <div className="col-span-2 text-center">对手对手胜率</div>
            <div className="col-span-3 text-center">比赛历史</div>
          </div>
        </div>
        
        <div className="space-y-1">
          {rankedPlayers.map((player, index) => {
            const rank = index + 1;
            const history = getPlayerMatchHistory(player.id);
            
            return (
              <div
                key={player.id}
                className={`
                  grid grid-cols-12 gap-2 px-4 py-3 rounded-lg items-center transition-all
                  ${rank <= 3 ? 'bg-slate-800/50' : 'bg-slate-800/30'}
                  ${rank === 1 ? 'border-l-2 border-yellow-400' : ''}
                  ${player.dropped ? 'opacity-50' : ''}
                  hover:bg-slate-800/60
                `}
              >
                <div className="col-span-1 flex items-center">
                  {getRankBadge(rank)}
                </div>

                <div className="col-span-3">
                  <span className={`font-medium ${
                    rank === 1 ? 'text-yellow-400' : player.dropped ? 'text-slate-400' : 'text-white'
                  }`}>
                    {player.name}
                  </span>
                  {player.dropped && (
                    <span className="ml-1.5 text-[10px] px-1.5 py-0.5 rounded bg-rose-500/20 text-rose-400 border border-rose-500/30">
                      弃赛
                    </span>
                  )}
                </div>
                
                <div className="col-span-1 text-center">
                  <span className="font-mono font-bold text-sm text-white">
                    {player.wins}-{player.losses}
                  </span>
                </div>
                
                <div className="col-span-2 text-center">
                  <span className="text-sm text-slate-300">
                    {Math.round(player.opponentWinRate * 100)}%
                  </span>
                </div>
                
                <div className="col-span-2 text-center">
                  <span className="text-sm text-slate-300">
                    {Math.round(player.opponentOpponentWinRate * 100)}%
                  </span>
                </div>
                
                <div className="col-span-3 flex gap-1 justify-center">
                  {history.length > 0 ? (
                    history.map((h, i) => (
                      <div key={i}>{getResultBlock(h.result)}</div>
                    ))
                  ) : (
                    <span className="text-xs text-slate-500">无结果</span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
      
      <div className="mt-4 pt-4 border-t border-slate-700/50">
        <div className="flex items-center justify-center gap-6 text-xs text-slate-500">
          <div className="flex items-center gap-1.5">
            <div className="w-3 h-3 rounded bg-red-500"></div>
            <span>胜</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-3 h-3 rounded bg-black border border-slate-600"></div>
            <span>负</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-3 h-3 rounded bg-amber-500"></div>
            <span>轮空</span>
          </div>
        </div>
      </div>
    </div>
  );
}
