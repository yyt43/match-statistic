import type { Tournament } from '../types';

const STORAGE_KEY = 'swiss_tournament_data';

export function saveTournament(tournament: Tournament): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(tournament));
  } catch (e) {
    console.error('Failed to save tournament:', e);
  }
}

export function loadTournament(): Tournament | null {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    if (data) {
      return JSON.parse(data) as Tournament;
    }
  } catch (e) {
    console.error('Failed to load tournament:', e);
  }
  return null;
}

export function clearTournament(): void {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch (e) {
    console.error('Failed to clear tournament:', e);
  }
}
