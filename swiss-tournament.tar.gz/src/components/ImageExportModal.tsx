import { useState } from 'react';
import { X, Download, Camera, Trophy, Swords } from 'lucide-react';
import { RankingImageView } from './RankingImageView';
import { MatchImageView } from './MatchImageView';
import { generateImage } from '../utils/imageExport';
import { useTournamentStore } from '../store/useTournamentStore';

type ExportType = 'ranking' | 'match';

interface ImageExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialType?: ExportType;
}

export function ImageExportModal({ isOpen, onClose, initialType = 'ranking' }: ImageExportModalProps) {
  const [activeType, setActiveType] = useState<ExportType>(initialType);
  const [isGenerating, setIsGenerating] = useState(false);
  const { tournament, viewRound } = useTournamentStore();

  if (!isOpen) return null;

  const handleDownload = async () => {
    setIsGenerating(true);
    try {
      const elementId = activeType === 'ranking' ? 'ranking-image' : 'match-image';
      const fileName = activeType === 'ranking'
        ? `${tournament.name}-排行榜`
        : `${tournament.name}-第${viewRound}轮对阵表`;
      await generateImage(elementId, fileName);
    } catch (error) {
      console.error('生成图片失败:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
      <div className="relative w-full max-w-5xl max-h-[90vh] bg-slate-900 rounded-2xl border border-slate-700 shadow-2xl flex flex-col">
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-700">
          <h3 className="text-lg font-bold text-white flex items-center gap-2">
            <Camera className="w-5 h-5 text-gold-400" />
            导出图片
          </h3>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="px-5 py-3 border-b border-slate-700">
          <div className="flex gap-2">
            <button
              onClick={() => setActiveType('ranking')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                activeType === 'ranking'
                  ? 'bg-gold-500/20 text-gold-400 border border-gold-500/30'
                  : 'bg-slate-800/50 text-slate-400 hover:bg-slate-800'
              }`}
            >
              <Trophy className="w-4 h-4" />
              排行榜
            </button>
            <button
              onClick={() => setActiveType('match')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                activeType === 'match'
                  ? 'bg-gold-500/20 text-gold-400 border border-gold-500/30'
                  : 'bg-slate-800/50 text-slate-400 hover:bg-slate-800'
              }`}
            >
              <Swords className="w-4 h-4" />
              对阵表
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-auto p-5 bg-slate-950/50">
          <div className="flex justify-center min-w-fit">
            {activeType === 'ranking' ? <RankingImageView /> : <MatchImageView />}
          </div>
        </div>

        <div className="flex items-center justify-end gap-3 px-5 py-4 border-t border-slate-700">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg text-sm text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            取消
          </button>
          <button
            onClick={handleDownload}
            disabled={isGenerating}
            className="flex items-center gap-2 px-5 py-2 rounded-lg btn-primary text-sm disabled:opacity-50"
          >
            <Download className="w-4 h-4" />
            {isGenerating ? '生成中...' : '下载图片'}
          </button>
        </div>
      </div>
    </div>
  );
}
