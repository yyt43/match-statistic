import { create } from 'zustand';
import type { Tournament, Player, Match, MatchResult, TournamentStatus } from '../types';
import { generateSwissPairings, calculateAllWinRates, getRankedPlayers, createPlayersFromNames } from '../utils/swissPairing';
import { saveTournament, loadTournament, clearTournament } from '../utils/storage';

function generateId(): string {
  return Math.random().toString(36).substring(2, 11);
}

function createNewTournament(name: string, playerCount: number = 32, rounds: number = 5): Tournament {
  const demoNames: string[] = [];
  for (let i = 1; i <= playerCount; i++) {
    demoNames.push(`选手${String(i).padStart(3, '0')}`);
  }
  
  const players = createPlayersFromNames(demoNames);
  
  return {
    id: generateId(),
    name,
    mode: 'single',
    currentRound: 0,
    totalRounds: rounds,
    status: 'setup',
    players,
    matches: [],
    createdAt: new Date().toISOString(),
  };
}

interface TournamentState {
  tournament: Tournament;
  viewRound: number;
  
  initTournament: (name: string, playerCount?: number, rounds?: number) => void;
  loadSavedTournament: () => boolean;
  updateTournamentName: (name: string) => void;
  
  addPlayer: (name: string) => void;
  addPlayers: (names: string[]) => void;
  removePlayer: (playerId: string) => void;
  updatePlayerName: (playerId: string, name: string) => void;
  togglePlayerDropped: (playerId: string) => void;
  setPlayerCount: (count: number) => void;
  setTotalRounds: (rounds: number) => void;
  
  startTournament: (totalRounds: number) => void;
  generateNextRound: () => void;
  updateMatchResult: (matchId: string, result: MatchResult) => void;
  
  setViewRound: (round: number) => void;
  
  resetTournament: (playerCount?: number, rounds?: number) => void;
  
  getMatchesForRound: (round: number) => Match[];
  getRankedPlayers: () => Player[];
  isCurrentRoundComplete: () => boolean;
}

const initialTournament = createNewTournament('瑞士轮比赛');

export const useTournamentStore = create<TournamentState>((set, get) => ({
  tournament: initialTournament,
  viewRound: 0,
  
  initTournament: (name: string, playerCount?: number, rounds?: number) => {
    const tournament = createNewTournament(name, playerCount, rounds);
    set({ tournament, viewRound: 0 });
    saveTournament(tournament);
  },
  
  loadSavedTournament: () => {
    const saved = loadTournament();
    if (saved) {
      set({ 
        tournament: saved, 
        viewRound: saved.currentRound > 0 ? saved.currentRound : 0,
      });
      return true;
    }
    return false;
  },
  
  updateTournamentName: (name: string) => {
    const { tournament } = get();
    const updated = { ...tournament, name: name.trim() || '瑞士轮比赛' };
    set({ tournament: updated });
    saveTournament(updated);
  },
  
  addPlayer: (name: string) => {
    const { tournament } = get();
    if (tournament.status !== 'setup') return;
    
    const newPlayer: Player = {
      id: generateId(),
      name: name.trim(),
      points: 0,
      wins: 0,
      losses: 0,
      winRate: 0,
      opponentWinRate: 0,
      opponentOpponentWinRate: 0,
      playedAgainst: [],
      dropped: false,
    };
    
    const updated = {
      ...tournament,
      players: [...tournament.players, newPlayer],
    };
    
    set({ tournament: updated });
    saveTournament(updated);
  },
  
  addPlayers: (names: string[]) => {
    const { tournament } = get();
    if (tournament.status !== 'setup') return;
    
    const newPlayers: Player[] = names
      .filter(n => n.trim())
      .map(name => ({
        id: generateId(),
        name: name.trim(),
        points: 0,
        wins: 0,
        losses: 0,
        winRate: 0,
        opponentWinRate: 0,
        opponentOpponentWinRate: 0,
        playedAgainst: [],
        dropped: false,
      }));
    
    const updated = {
      ...tournament,
      players: [...tournament.players, ...newPlayers],
    };
    
    set({ tournament: updated });
    saveTournament(updated);
  },
  
  removePlayer: (playerId: string) => {
    const { tournament } = get();
    if (tournament.status !== 'setup') return;
    
    const updated = {
      ...tournament,
      players: tournament.players.filter(p => p.id !== playerId),
    };
    
    set({ tournament: updated });
    saveTournament(updated);
  },
  
  updatePlayerName: (playerId: string, name: string) => {
    const { tournament } = get();

    const updated = {
      ...tournament,
      players: tournament.players.map(p =>
        p.id === playerId ? { ...p, name: name.trim() } : p
      ),
    };

    set({ tournament: updated });
    saveTournament(updated);
  },

  togglePlayerDropped: (playerId: string) => {
    const { tournament } = get();
    if (tournament.status !== 'in_progress') return;

    const player = tournament.players.find(p => p.id === playerId);
    if (!player) return;

    const updated = {
      ...tournament,
      players: tournament.players.map(p =>
        p.id === playerId ? { ...p, dropped: !p.dropped } : p
      ),
    };

    set({ tournament: updated });
    saveTournament(updated);
  },

  setPlayerCount: (count: number) => {
    const { tournament } = get();
    if (tournament.status !== 'setup') return;

    const newCount = Math.max(2, Math.min(200, count));
    const currentCount = tournament.players.length;

    if (newCount === currentCount) return;

    const updatedPlayers = [...tournament.players];

    if (newCount > currentCount) {
      for (let i = currentCount + 1; i <= newCount; i++) {
        updatedPlayers.push({
          id: generateId(),
          name: `选手${String(i).padStart(3, '0')}`,
          points: 0,
          wins: 0,
          losses: 0,
          winRate: 0,
          opponentWinRate: 0,
          opponentOpponentWinRate: 0,
          playedAgainst: [],
          dropped: false,
        });
      }
    } else {
      updatedPlayers.splice(newCount);
    }

    const updated = {
      ...tournament,
      players: updatedPlayers,
    };

    set({ tournament: updated });
    saveTournament(updated);
  },

  setTotalRounds: (rounds: number) => {
    const { tournament } = get();
    if (tournament.status !== 'setup') return;

    const newRounds = Math.max(1, Math.min(20, rounds));

    const updated = {
      ...tournament,
      totalRounds: newRounds,
    };

    set({ tournament: updated });
    saveTournament(updated);
  },

  startTournament: (totalRounds: number) => {
    const { tournament } = get();
    if (tournament.players.length < 2) return;
    
    const updated = {
      ...tournament,
      totalRounds,
      status: 'in_progress' as TournamentStatus,
      currentRound: 0,
    };
    
    set({ tournament: updated });
    saveTournament(updated);
    
    get().generateNextRound();
  },
  
  generateNextRound: () => {
    const { tournament } = get();
    if (tournament.status !== 'in_progress') return;
    
    const nextRound = tournament.currentRound + 1;
    if (nextRound > tournament.totalRounds) return;
    
    const matches = generateSwissPairings(tournament.players, nextRound);
    
    const updated = {
      ...tournament,
      currentRound: nextRound,
      matches: [...tournament.matches, ...matches],
    };
    
    set({ tournament: updated, viewRound: nextRound });
    saveTournament(updated);
  },
  
  updateMatchResult: (matchId: string, result: MatchResult) => {
    const { tournament } = get();
    
    const matchIndex = tournament.matches.findIndex(m => m.id === matchId);
    if (matchIndex === -1) return;
    
    const match = tournament.matches[matchIndex];
    if (match.isBye) return;
    
    const oldResult = match.result;
    
    const playerMap = new Map<string, Player>(tournament.players.map(p => [p.id, { ...p }]));
    
    function revertResult(p1Id: string, p2Id: string, res: MatchResult) {
      const p1 = playerMap.get(p1Id);
      const p2 = playerMap.get(p2Id);
      if (!p1 || !p2) return;
      
      if (res === 'player1') {
        p1.points -= 1;
        p1.wins -= 1;
        p2.losses -= 1;
        p1.playedAgainst = p1.playedAgainst.filter(id => id !== p2Id);
        p2.playedAgainst = p2.playedAgainst.filter(id => id !== p1Id);
      } else if (res === 'player2') {
        p2.points -= 1;
        p2.wins -= 1;
        p1.losses -= 1;
        p1.playedAgainst = p1.playedAgainst.filter(id => id !== p2Id);
        p2.playedAgainst = p2.playedAgainst.filter(id => id !== p1Id);
      }
    }
    
    function applyResult(p1Id: string, p2Id: string, res: MatchResult) {
      const p1 = playerMap.get(p1Id);
      const p2 = playerMap.get(p2Id);
      if (!p1 || !p2) return;
      
      if (res === 'player1') {
        p1.points += 1;
        p1.wins += 1;
        p2.losses += 1;
        p1.playedAgainst.push(p2Id);
        p2.playedAgainst.push(p1Id);
      } else if (res === 'player2') {
        p2.points += 1;
        p2.wins += 1;
        p1.losses += 1;
        p1.playedAgainst.push(p2Id);
        p2.playedAgainst.push(p1Id);
      }
    }
    
    if (oldResult !== 'pending') {
      revertResult(match.player1Id, match.player2Id, oldResult);
    }
    
    if (result !== 'pending') {
      applyResult(match.player1Id, match.player2Id, result);
    }
    
    const updatedMatches = [...tournament.matches];
    updatedMatches[matchIndex] = { ...match, result };
    
    let updatedPlayers = Array.from(playerMap.values());
    updatedPlayers = calculateAllWinRates(updatedPlayers, updatedMatches);
    
    const rankedPlayers = getRankedPlayers(updatedPlayers);
    const previousRankMap = new Map(
      getRankedPlayers(tournament.players).map((p, i) => [p.id, i + 1])
    );
    
    updatedPlayers = rankedPlayers.map(p => ({
      ...p,
      previousRank: previousRankMap.get(p.id),
    }));
    
    const allCurrentRoundMatches = updatedMatches.filter(m => m.round === tournament.currentRound);
    const allDone = allCurrentRoundMatches.length > 0 && allCurrentRoundMatches.every(m => m.result !== 'pending');
    const isLastRound = tournament.currentRound >= tournament.totalRounds;
    
    const updated = {
      ...tournament,
      matches: updatedMatches,
      players: updatedPlayers,
      status: allDone && isLastRound ? 'completed' as TournamentStatus : tournament.status,
    };
    
    set({ tournament: updated });
    saveTournament(updated);
  },
  
  setViewRound: (round: number) => {
    set({ viewRound: round });
  },
  
  resetTournament: (playerCount?: number, rounds?: number) => {
    const tournament = createNewTournament('瑞士轮比赛', playerCount, rounds);
    set({ tournament, viewRound: 0 });
    clearTournament();
  },
  
  getMatchesForRound: (round: number) => {
    const { tournament } = get();
    return tournament.matches.filter(m => m.round === round);
  },
  
  getRankedPlayers: () => {
    const { tournament } = get();
    return getRankedPlayers(tournament.players);
  },
  
  isCurrentRoundComplete: () => {
    const { tournament } = get();
    if (tournament.currentRound === 0) return false;
    
    const currentMatches = tournament.matches.filter(m => m.round === tournament.currentRound);
    return currentMatches.length > 0 && currentMatches.every(m => m.result !== 'pending');
  },
}));
