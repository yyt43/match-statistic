import type { Player, Match } from '../types';

function generateId(): string {
  return Math.random().toString(36).substring(2, 11);
}

function sortPlayersByRank(players: Player[]): Player[] {
  return [...players].sort((a, b) => {
    if (b.winRate !== a.winRate) return b.winRate - a.winRate;
    if (b.opponentWinRate !== a.opponentWinRate) return b.opponentWinRate - a.opponentWinRate;
    if (b.opponentOpponentWinRate !== a.opponentOpponentWinRate) return b.opponentOpponentWinRate - a.opponentOpponentWinRate;
    if (b.points !== a.points) return b.points - a.points;
    return a.name.localeCompare(b.name);
  });
}

function hasPlayedAgainst(player1: Player, player2: Player): boolean {
  return player1.playedAgainst.includes(player2.id);
}

function swapPair(players: Player[], i: number, j: number): Player[] {
  const result = [...players];
  [result[i], result[j]] = [result[j], result[i]];
  return result;
}

function canFormValidPairs(players: Player[]): boolean {
  for (let i = 0; i < players.length; i += 2) {
    if (i + 1 >= players.length) break;
    if (hasPlayedAgainst(players[i], players[i + 1])) {
      return false;
    }
  }
  return true;
}

function findValidPairing(sortedPlayers: Player[], depth: number = 0): Player[] | null {
  if (depth > 200) return null;
  
  if (canFormValidPairs(sortedPlayers)) {
    return sortedPlayers;
  }

  for (let i = 0; i < sortedPlayers.length; i += 2) {
    if (i + 1 >= sortedPlayers.length) continue;
    if (!hasPlayedAgainst(sortedPlayers[i], sortedPlayers[i + 1])) continue;
    
    for (let j = i + 2; j < sortedPlayers.length; j++) {
      const swapped = swapPair(sortedPlayers, i + 1, j);
      if (!hasPlayedAgainst(swapped[i], swapped[i + 1])) {
        const front = swapped.slice(0, i + 2);
        const back = swapped.slice(i + 2);
        const result = findValidPairing(back, depth + 1);
        if (result) {
          return [...front, ...result];
        }
      }
    }
  }

  for (let i = 0; i < sortedPlayers.length; i++) {
    for (let j = i + 1; j < sortedPlayers.length; j++) {
      if (Math.floor(i / 2) === Math.floor(j / 2)) continue;
      const swapped = swapPair(sortedPlayers, i, j);
      const result = findValidPairing(swapped, depth + 1);
      if (result) return result;
    }
  }

  return null;
}

export function generateSwissPairings(
  players: Player[],
  round: number
): Match[] {
  const matches: Match[] = [];

  const activePool = players.filter(p => !p.dropped);
  let byePlayer: Player | null = null;
  let activePlayers: Player[];

  if (round === 1) {
    activePlayers = [...activePool].sort(() => Math.random() - 0.5);
  } else {
    activePlayers = [...activePool].sort((a, b) => {
      if (b.points !== a.points) return b.points - a.points;
      if (b.wins !== a.wins) return b.wins - a.wins;
      return a.name.localeCompare(b.name);
    });
  }

  if (activePlayers.length % 2 !== 0) {
    for (let i = activePlayers.length - 1; i >= 0; i--) {
      if (!activePlayers[i].playedAgainst.includes('bye')) {
        byePlayer = activePlayers[i];
        activePlayers.splice(i, 1);
        break;
      }
    }
    if (!byePlayer) {
      byePlayer = activePlayers.pop()!;
    }
  }

  let pairedPlayers = findValidPairing(activePlayers);
  
  if (!pairedPlayers) {
    pairedPlayers = activePlayers;
  }

  for (let i = 0; i < pairedPlayers.length; i += 2) {
    if (i + 1 >= pairedPlayers.length) break;
    
    const p1 = pairedPlayers[i];
    const p2 = pairedPlayers[i + 1];
    
    matches.push({
      id: generateId(),
      round,
      player1Id: p1.id,
      player2Id: p2.id,
      result: 'pending',
    });
  }

  if (byePlayer) {
    matches.push({
      id: generateId(),
      round,
      player1Id: byePlayer.id,
      player2Id: 'bye',
      result: 'player1',
      isBye: true,
    });
  }

  return matches;
}

function calculateWinRate(player: Player): number {
  const total = player.wins + player.losses;
  if (total === 0) return 0;
  return player.wins / total;
}

export function calculateAllWinRates(
  players: Player[],
  matches: Match[]
): Player[] {
  const playerMap = new Map(players.map(p => [p.id, { ...p }]));
  
  for (const player of playerMap.values()) {
    player.winRate = calculateWinRate(player);
  }
  
  for (let iteration = 0; iteration < 3; iteration++) {
    const currentRates = new Map<string, number>();
    for (const [id, player] of playerMap) {
      if (iteration === 0) {
        currentRates.set(id, player.winRate);
      } else if (iteration === 1) {
        currentRates.set(id, player.opponentWinRate);
      } else {
        currentRates.set(id, player.opponentOpponentWinRate);
      }
    }
    
    for (const player of playerMap.values()) {
      let opponentRateSum = 0;
      let opponentCount = 0;
      
      for (const match of matches) {
        if (match.isBye) continue;
        
        let opponentId: string | null = null;
        
        if (match.player1Id === player.id) {
          opponentId = match.player2Id;
        } else if (match.player2Id === player.id) {
          opponentId = match.player1Id;
        }
        
        if (opponentId && match.result !== 'pending') {
          const rate = currentRates.get(opponentId);
          if (rate !== undefined) {
            opponentRateSum += rate;
            opponentCount++;
          }
        }
      }
      
      const avgRate = opponentCount > 0 ? opponentRateSum / opponentCount : 0;
      
      if (iteration === 0) {
        player.opponentWinRate = avgRate;
      } else if (iteration === 1) {
        player.opponentOpponentWinRate = avgRate;
      }
    }
  }
  
  return Array.from(playerMap.values());
}

export function getRankedPlayers(players: Player[]): Player[] {
  return sortPlayersByRank(players);
}

export function getWinRate(player: Player): number {
  return player.winRate;
}

export function createPlayersFromNames(playerNames: string[]): Player[] {
  return playerNames.map((name, index) => ({
    id: generateId(),
    name: name.trim(),
    points: 0,
    wins: 0,
    losses: 0,
    winRate: 0,
    opponentWinRate: 0,
    opponentOpponentWinRate: 0,
    playedAgainst: [],
    previousRank: index + 1,
    dropped: false,
  }));
}
