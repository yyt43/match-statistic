import { useState } from 'react';
import { Users, Play, RotateCcw, Settings, AlertTriangle, Trophy, Edit2, UserX, UserCheck, Trash2 } from 'lucide-react';
import { useTournamentStore } from '../store/useTournamentStore';

export function ControlPanel() {
  const {
    tournament,
    startTournament,
    generateNextRound,
    isCurrentRoundComplete,
    resetTournament,
    updateTournamentName,
    updatePlayerName,
    togglePlayerDropped,
    removePlayer,
    setPlayerCount,
    setTotalRounds,
  } = useTournamentStore();

  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [nameInput, setNameInput] = useState(tournament.name);
  const [isEditingName, setIsEditingName] = useState(false);
  const [editingPlayerId, setEditingPlayerId] = useState<string | null>(null);
  const [editNameValue, setEditNameValue] = useState('');
  const [showPlayerManager, setShowPlayerManager] = useState(false);

  const handleStartTournament = () => {
    if (tournament.players.length < 2) return;
    startTournament(tournament.totalRounds);
  };

  const canGenerateNext =
    tournament.status === 'in_progress' &&
    isCurrentRoundComplete() &&
    tournament.currentRound < tournament.totalRounds;

  const isLastRoundComplete =
    tournament.status === 'in_progress' &&
    isCurrentRoundComplete() &&
    tournament.currentRound >= tournament.totalRounds;

  const handleStartEditName = (player: { id: string; name: string }) => {
    setEditingPlayerId(player.id);
    setEditNameValue(player.name);
  };

  const handleConfirmEditName = () => {
    if (editingPlayerId && editNameValue.trim()) {
      updatePlayerName(editingPlayerId, editNameValue.trim());
    }
    setEditingPlayerId(null);
    setEditNameValue('');
  };

  const activePlayers = tournament.players.filter(p => !p.dropped);
  const droppedPlayers = tournament.players.filter(p => p.dropped);

  return (
    <div className="glass-panel rounded-2xl p-5 h-full flex flex-col">
      <h2 className="font-display text-lg font-bold text-white flex items-center gap-2 mb-4">
        <Settings className="w-5 h-5 text-gold-400" />
        比赛控制
      </h2>

      <div className="flex-1 overflow-y-auto space-y-5 pr-1">
        {tournament.status === 'setup' && (
          <div className="space-y-2">
            <label className="text-sm text-slate-400">比赛名称</label>
            {isEditingName ? (
              <div className="flex gap-2">
                <input
                  type="text"
                  value={nameInput}
                  onChange={e => setNameInput(e.target.value)}
                  onKeyDown={e => {
                    if (e.key === 'Enter') {
                      updateTournamentName(nameInput);
                      setIsEditingName(false);
                    }
                  }}
                  autoFocus
                  className="flex-1 px-3 py-2 bg-slate-800/50 border border-gold-500/50 rounded-lg text-white placeholder-slate-500 focus:outline-none text-sm"
                />
                <button
                  onClick={() => {
                    updateTournamentName(nameInput);
                    setIsEditingName(false);
                  }}
                  className="px-3 py-2 rounded-lg btn-primary text-sm"
                >
                  确认
                </button>
              </div>
            ) : (
              <div
                onClick={() => {
                  setNameInput(tournament.name);
                  setIsEditingName(true);
                }}
                className="px-3 py-2 bg-slate-800/30 border border-slate-700/50 rounded-lg text-white cursor-pointer hover:border-gold-500/30 transition-colors"
              >
                {tournament.name}
                <span className="text-xs text-slate-500 ml-2">点击修改</span>
              </div>
            )}
          </div>
        )}

        {tournament.status === 'setup' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-sm text-slate-400 flex items-center gap-2">
                <Users className="w-4 h-4" />
                参赛选手 ({tournament.players.length})
              </label>
            </div>

            <div className="space-y-2">
              <label className="text-xs text-slate-500">设置参赛人数</label>
              <div className="flex items-center gap-3">
                <input
                  type="range"
                  min="2"
                  max="100"
                  value={tournament.players.length}
                  onChange={e => setPlayerCount(parseInt(e.target.value))}
                  className="flex-1 accent-gold-500"
                />
                <span className="w-12 text-center font-mono text-gold-400 font-bold">
                  {tournament.players.length}
                </span>
              </div>
            </div>

            {tournament.players.length > 0 && (
              <div className="max-h-48 overflow-y-auto space-y-1">
                {tournament.players.map((player, index) => (
                  <div
                    key={player.id}
                    className="flex items-center gap-2 px-3 py-2 bg-slate-800/30 rounded-lg group hover:bg-slate-800/50 transition-colors"
                  >
                    <span className="text-slate-500 font-mono text-xs w-6">{index + 1}.</span>
                    {editingPlayerId === player.id ? (
                      <>
                        <input
                          type="text"
                          value={editNameValue}
                          onChange={e => setEditNameValue(e.target.value)}
                          onKeyDown={e => {
                            if (e.key === 'Enter') handleConfirmEditName();
                            if (e.key === 'Escape') {
                              setEditingPlayerId(null);
                              setEditNameValue('');
                            }
                          }}
                          autoFocus
                          className="flex-1 px-2 py-1 bg-slate-700 border border-gold-500/50 rounded text-sm text-white focus:outline-none"
                        />
                        <button
                          onClick={handleConfirmEditName}
                          className="px-2 py-1 rounded text-xs bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30"
                        >
                          确认
                        </button>
                      </>
                    ) : (
                      <>
                        <span className="flex-1 text-sm text-slate-300 truncate">{player.name}</span>
                        <button
                          onClick={() => handleStartEditName(player)}
                          className="p-1 rounded hover:bg-slate-700 text-slate-400 hover:text-white transition-colors opacity-0 group-hover:opacity-100"
                          title="修改名称"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => removePlayer(player.id)}
                          className="p-1 rounded hover:bg-rose-500/10 text-slate-400 hover:text-rose-400 transition-colors opacity-0 group-hover:opacity-100"
                          title="删除选手"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {tournament.status === 'setup' && (
          <div className="space-y-3 pt-3 border-t border-slate-700/50">
            <div className="space-y-2">
              <label className="text-sm text-slate-400">比赛轮次</label>
              <div className="flex items-center gap-3">
                <input
                  type="range"
                  min="1"
                  max="10"
                  value={tournament.totalRounds}
                  onChange={e => setTotalRounds(parseInt(e.target.value))}
                  className="flex-1 accent-gold-500"
                />
                <span className="w-12 text-center font-mono text-gold-400 font-bold">
                  {tournament.totalRounds}
                </span>
              </div>
              <p className="text-xs text-slate-500">
                {tournament.totalRounds} 轮瑞士轮赛制
              </p>
            </div>

            {tournament.players.length % 2 !== 0 && (
              <div className="text-xs text-amber-400 bg-amber-500/10 rounded-lg px-3 py-2">
                ⚠️ 当前参赛人数为奇数，首轮将安排战绩最低的选手轮空
              </div>
            )}

            <button
              onClick={handleStartTournament}
              disabled={tournament.players.length < 2}
              className="w-full py-3 rounded-xl btn-primary font-semibold flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Play className="w-5 h-5" />
              开始比赛
            </button>
          </div>
        )}

        {tournament.status === 'in_progress' && (
          <div className="space-y-4">
            <div className="bg-slate-800/40 rounded-xl p-4 space-y-3">
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-400">当前进度</span>
                <span className="font-mono text-gold-400">
                  {tournament.currentRound} / {tournament.totalRounds}
                </span>
              </div>
              <div className="h-2 bg-slate-700/50 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-gold-500 to-gold-400 rounded-full transition-all duration-500"
                  style={{ width: `${(tournament.currentRound / tournament.totalRounds) * 100}%` }}
                />
              </div>
              <div className="flex items-center justify-between text-xs text-slate-500 pt-1">
                <span>参赛 {activePlayers.length} 人</span>
                {droppedPlayers.length > 0 && (
                  <span className="text-rose-400">弃赛 {droppedPlayers.length} 人</span>
                )}
              </div>
            </div>

            {canGenerateNext && (
              <>
                <button
                  onClick={generateNextRound}
                  className="w-full py-3 rounded-xl btn-primary font-semibold flex items-center justify-center gap-2 animate-pulse-glow"
                >
                  <Play className="w-5 h-5" />
                  生成第 {tournament.currentRound + 1} 轮对阵
                </button>

                <div className="border-t border-slate-700/50 pt-4">
                  <button
                    onClick={() => setShowPlayerManager(!showPlayerManager)}
                    className="w-full py-2.5 rounded-lg bg-slate-800/50 text-slate-300 hover:bg-slate-800 hover:text-white transition-colors text-sm flex items-center justify-center gap-2"
                  >
                    <Users className="w-4 h-4" />
                    {showPlayerManager ? '收起选手管理' : '选手管理（修改名称/弃赛）'}
                  </button>

                  {showPlayerManager && (
                    <div className="mt-3 space-y-2 max-h-64 overflow-y-auto">
                      {tournament.players.map((player) => (
                        <div
                          key={player.id}
                          className={`flex items-center gap-2 px-3 py-2 rounded-lg ${
                            player.dropped ? 'bg-rose-500/10' : 'bg-slate-800/30'
                          }`}
                        >
                          {editingPlayerId === player.id ? (
                            <>
                              <input
                                type="text"
                                value={editNameValue}
                                onChange={e => setEditNameValue(e.target.value)}
                                onKeyDown={e => {
                                  if (e.key === 'Enter') handleConfirmEditName();
                                  if (e.key === 'Escape') {
                                    setEditingPlayerId(null);
                                    setEditNameValue('');
                                  }
                                }}
                                autoFocus
                                className="flex-1 px-2 py-1 bg-slate-700 border border-gold-500/50 rounded text-sm text-white focus:outline-none"
                              />
                              <button
                                onClick={handleConfirmEditName}
                                className="px-2 py-1 rounded text-xs bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30"
                              >
                                确认
                              </button>
                            </>
                          ) : (
                            <>
                              <span className={`flex-1 text-sm truncate ${
                                player.dropped ? 'text-slate-500 line-through' : 'text-white'
                              }`}>
                                {player.name}
                              </span>
                              <button
                                onClick={() => handleStartEditName(player)}
                                className="p-1 rounded hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
                                title="修改名称"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => togglePlayerDropped(player.id)}
                                className={`p-1 rounded transition-colors ${
                                  player.dropped
                                    ? 'text-emerald-400 hover:bg-emerald-500/10'
                                    : 'text-rose-400 hover:bg-rose-500/10'
                                }`}
                                title={player.dropped ? '恢复参赛' : '标记弃赛'}
                              >
                                {player.dropped ? <UserCheck className="w-3.5 h-3.5" /> : <UserX className="w-3.5 h-3.5" />}
                              </button>
                            </>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </>
            )}

            {!isCurrentRoundComplete() && tournament.currentRound > 0 && (
              <div className="text-center text-sm text-amber-400 bg-amber-500/10 rounded-xl py-3 px-4">
                <AlertTriangle className="w-4 h-4 inline mr-2 -mt-1" />
                请先完成当前轮所有比赛
              </div>
            )}

            {isLastRoundComplete && (
              <div className="text-center text-sm text-emerald-400 bg-emerald-500/10 rounded-xl py-3 px-4">
                🎉 所有轮次已完成！
              </div>
            )}
          </div>
        )}

        {tournament.status === 'completed' && (
          <div className="text-center py-6">
            <div className="text-5xl mb-4">🏆</div>
            <h3 className="text-xl font-bold gold-gradient mb-2">比赛结束</h3>
            <p className="text-sm text-slate-400">
              共进行 {tournament.totalRounds} 轮比赛
            </p>
            <div className="mt-4 text-xs text-slate-500">
              排名依据：胜率 → 对手胜率 → 对手对手胜率
            </div>
          </div>
        )}
      </div>

      <div className="pt-4 mt-4 border-t border-slate-700/50">
        {showResetConfirm ? (
          <div className="space-y-3">
            <p className="text-sm text-rose-400 text-center">
              确认重置所有数据？此操作不可撤销
            </p>
            <div className="flex gap-2">
              <button
                onClick={() => {
                  resetTournament();
                  setShowResetConfirm(false);
                }}
                className="flex-1 py-2 rounded-lg bg-rose-500/20 text-rose-400 hover:bg-rose-500/30 text-sm font-medium transition-colors"
              >
                确认重置
              </button>
              <button
                onClick={() => setShowResetConfirm(false)}
                className="flex-1 py-2 rounded-lg btn-secondary text-sm"
              >
                取消
              </button>
            </div>
          </div>
        ) : (
          <button
            onClick={() => setShowResetConfirm(true)}
            className="w-full py-2.5 rounded-lg btn-secondary text-sm flex items-center justify-center gap-2 text-slate-400 hover:text-slate-300"
          >
            <RotateCcw className="w-4 h-4" />
            重置比赛
          </button>
        )}
      </div>
    </div>
  );
}
