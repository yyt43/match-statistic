import { useEffect, useState } from 'react';
import { Header } from '../components/Header';
import { PlayerRanking } from '../components/PlayerRanking';
import { MatchList } from '../components/MatchList';
import { ControlPanel } from '../components/ControlPanel';
import { ImageExportModal } from '../components/ImageExportModal';
import { useTournamentStore } from '../store/useTournamentStore';

export default function Home() {
  const { loadSavedTournament, tournament } = useTournamentStore();
  const [isExportOpen, setIsExportOpen] = useState(false);
  const [exportType, setExportType] = useState<'ranking' | 'match'>('ranking');
  
  useEffect(() => {
    loadSavedTournament();
  }, [loadSavedTournament]);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1 px-4 md:px-6 py-6">
        <div className="max-w-7xl mx-auto">
          <div className="mb-4 flex items-center justify-end gap-2">
            <button
              onClick={() => {
                setExportType('ranking');
                setIsExportOpen(true);
              }}
              disabled={tournament.currentRound === 0}
              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-slate-800/50 text-slate-300 hover:bg-slate-700/50 hover:text-white transition-colors text-sm disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <span>导出排行榜图片</span>
            </button>
            <button
              onClick={() => {
                setExportType('match');
                setIsExportOpen(true);
              }}
              disabled={tournament.currentRound === 0}
              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-slate-800/50 text-slate-300 hover:bg-slate-700/50 hover:text-white transition-colors text-sm disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <span>导出对阵表图片</span>
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-3 order-2 lg:order-1">
              <div className="h-[600px] lg:h-[calc(100vh-220px)]">
                <PlayerRanking />
              </div>
            </div>
            
            <div className="lg:col-span-6 order-1 lg:order-2">
              <div className="h-[600px] lg:h-[calc(100vh-220px)]">
                <MatchList />
              </div>
            </div>
            
            <div className="lg:col-span-3 order-3">
              <div className="h-[600px] lg:h-[calc(100vh-220px)]">
                <ControlPanel />
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <footer className="py-4 text-center text-xs text-slate-600">
        瑞士轮比赛战绩统计系统 · 本地数据存储
      </footer>

      <ImageExportModal
        isOpen={isExportOpen}
        onClose={() => setIsExportOpen(false)}
        initialType={exportType}
      />
    </div>
  );
}
