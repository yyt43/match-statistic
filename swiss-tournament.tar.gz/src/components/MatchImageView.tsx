import { useTournamentStore } from '../store/useTournamentStore';
import type { Match } from '../types';

export function MatchImageView() {
  const { tournament, viewRound } = useTournamentStore();

  const matches = tournament.matches.filter(m => m.round === viewRound);
  const playerMap = new Map(tournament.players.map(p => [p.id, p]));

  const getPlayerName = (id: string) => {
    if (id === 'bye') return '轮空';
    return playerMap.get(id)?.name || '未知选手';
  };

  const getScore = (match: Match, playerNum: 1 | 2) => {
    if (match.result === 'pending') return '-';
    if (match.isBye) return playerNum === 1 ? '1' : '0';
    if (match.result === 'player1') return playerNum === 1 ? '1' : '0';
    if (match.result === 'player2') return playerNum === 2 ? '1' : '0';
    return '0';
  };

  if (tournament.currentRound === 0) {
    return (
      <div id="match-image" className="p-6 bg-slate-900 min-h-[400px]">
        <div className="text-center text-slate-500 py-20">暂无对阵数据</div>
      </div>
    );
  }

  return (
    <div id="match-image" className="p-6 bg-slate-900" style={{ width: 1000 }}>
      <div className="bg-slate-800 rounded-lg overflow-hidden">
        <div className="px-5 py-3 bg-slate-700/50 border-b border-slate-700 flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-white">{tournament.name} - 第 {viewRound} 轮对阵表</h2>
            <p className="text-xs text-slate-400 mt-1">共 {matches.length} 场对阵</p>
          </div>
          <div className="px-3 py-1 bg-orange-500 rounded text-xs font-bold text-white">
            第 {viewRound} 轮
          </div>
        </div>

        <div className="p-4 grid grid-cols-2 gap-3">
          {matches.map((match, index) => (
            <div key={match.id} className="bg-slate-800/60 rounded-lg overflow-hidden">
              <div className="px-3 py-1.5 bg-slate-700/30 text-[10px] text-slate-400 text-right">
                BO1
              </div>

              <div className="flex">
                <div className="flex-1 p-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-white truncate max-w-[180px]">
                      {getPlayerName(match.player1Id)}
                    </span>
                    <span className="text-[10px] text-slate-500 ml-2">UID: {match.player1Id.slice(0, 9)}</span>
                  </div>
                </div>
                <div className={`
                  w-12 flex items-center justify-center text-lg font-bold text-white
                  ${getScore(match, 1) === '1' ? 'bg-orange-500' : 'bg-slate-700'}
                `}>
                  {getScore(match, 1)}
                </div>
              </div>

              <div className="flex">
                <div className="flex-1 p-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-white truncate max-w-[180px]">
                      {getPlayerName(match.player2Id)}
                    </span>
                    <span className="text-[10px] text-slate-500 ml-2">UID: {match.player2Id === 'bye' ? '0' : match.player2Id.slice(0, 9)}</span>
                  </div>
                </div>
                <div className={`
                  w-12 flex items-center justify-center text-lg font-bold text-white
                  ${getScore(match, 2) === '1' ? 'bg-orange-500' : 'bg-slate-700'}
                `}>
                  {getScore(match, 2)}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
