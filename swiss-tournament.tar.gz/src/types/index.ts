export type MatchResult = 'player1' | 'player2' | 'pending';

export type TournamentStatus = 'setup' | 'in_progress' | 'completed';

export type TournamentMode = 'single';

export interface Player {
  id: string;
  name: string;
  points: number;
  wins: number;
  losses: number;
  winRate: number;
  opponentWinRate: number;
  opponentOpponentWinRate: number;
  playedAgainst: string[];
  previousRank?: number;
  dropped?: boolean;
}

export interface Match {
  id: string;
  round: number;
  player1Id: string;
  player2Id: string;
  result: MatchResult;
  isBye?: boolean;
}

export interface Tournament {
  id: string;
  name: string;
  mode: TournamentMode;
  currentRound: number;
  totalRounds: number;
  status: TournamentStatus;
  players: Player[];
  matches: Match[];
  createdAt: string;
}

export interface AddPlayerData {
  name: string;
}

export interface MatchResultData {
  matchId: string;
  result: MatchResult;
}
